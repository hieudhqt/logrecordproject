﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Reso.AuthorizationBase.DbManager.Identity
{
    public class ResoJWTValidators
    {
        public static string AUDIENCE = "https://localhost:44328";
        public static string ISSUER = "https://localhost:44328";
        public static string SECRET_KEY = "@everone:ResoSecret27392!";

    }
}
