﻿using System;
using TNT.Core.Template.DataService.Data;

namespace TNT.Core.Template.DataService
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
