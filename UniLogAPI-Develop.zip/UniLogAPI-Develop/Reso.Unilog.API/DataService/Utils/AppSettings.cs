﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataService.Utils
{
    public  class AppSettings
    {
        public  string Secret { get; set; }
    }
}
