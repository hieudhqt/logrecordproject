﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataService.Models.Gen
{
    public  interface IDeleting
    {
        bool Active { get; set; }
    }
}
