﻿using Core.DataService.Models.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataService.Models.Filters
{
    public class AspNetUsersFilter: BaseFilter
    {
    }
}
